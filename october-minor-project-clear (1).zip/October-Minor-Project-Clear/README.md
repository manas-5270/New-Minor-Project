# October-Minor-Project — Business Budget Optimization Tool

## Open this project in VS Code
1. Extract this ZIP.
2. In VS Code choose **File → Open Folder**.
3. Select the extracted `October-Minor-Project-Clear` folder (the folder containing this README).
4. Open **Terminal → New Terminal**.

## Understand the folders (important)
- `frontend-user/` = the website interface that a normal business user sees in the browser. Login, dashboard, expenses, budget, optimization and business profile are here.
- `backend-server/` = server-side API and business logic. The browser sends requests here; users do not browse or edit this folder when using the deployed website.
- `backend-server/src/models/` = MongoDB data models.
- `backend-server/src/routes/` = API endpoints.
- `backend-server/src/services/optimizer.js` = budget variance and rule-based recommendation logic.
- `backend-server/src/middleware/auth.js` = checks signed-in user identity for protected endpoints.
- `frontend-user/src/pages/` = user-facing pages.
- `frontend-user/src/components/` = reusable interface components.
- `frontend-user/src/App.jsx` = routes/navigation for the user-facing website.

## Important clarification: User vs Admin
This version has a **business-user interface** and a **backend server**. The backend is NOT the admin panel. A separate, role-protected Admin Dashboard UI is **not implemented in this ZIP yet**; I don't want to mislead you by labeling server code as an admin screen. If your project requirements include admin screens (manage users, inspect system totals, admin-only actions), those need to be added separately with server-side role authorization.

## Run the project on Windows

### A. Start backend (Terminal 1)
```bat
cd backend-server
copy .env.example .env
npm install
npm run dev
```
Edit `backend-server/.env` and set your MongoDB connection string and a long random `JWT_SECRET`. MongoDB must be running locally or you must use a MongoDB Atlas connection string.

### B. Start frontend (Terminal 2)
Open a second VS Code terminal from the project root:
```bat
cd frontend-user
npm install
npm run dev
```
Open the local URL Vite prints (usually `http://localhost:5173`).

## If npm install fails with ECONNRESET
That means npm could not complete a network request. Check your connection and try:
```bat
npm install --registry=https://registry.npmjs.org/
```
Run that command inside the folder whose `package.json` you want to install.

## Project limitations
The optimization engine is rule-based. It compares budget and actual spending; it is not a trained AI model and does not guarantee savings or maximum profit. This is a college-project foundation, not production-certified financial software. Never upload `.env` or a real JWT secret to GitHub.
