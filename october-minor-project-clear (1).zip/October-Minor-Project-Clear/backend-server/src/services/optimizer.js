const roundMoney = n => Math.round((n + Number.EPSILON) * 100) / 100;
/** Transparent constrained baseline. No invented benchmark percentages or guaranteed savings. */
export function optimizeBudget({ totalBudget, reserveAmount = 0, categories = [], expenses = [] }) {
  const budget = Math.max(0, Number(totalBudget) || 0);
  const reserve = Math.max(0, Number(reserveAmount) || 0);
  const spendable = Math.max(0, budget - reserve);
  const spentByCategory = new Map();
  for (const e of expenses) spentByCategory.set(e.category, (spentByCategory.get(e.category) || 0) + Number(e.amount || 0));
  const allocated = categories.reduce((s,c)=>s+Math.max(0,Number(c.plannedAmount)||0),0);
  const lines = categories.map(c => {
    const planned = Math.max(0,Number(c.plannedAmount)||0), actual = spentByCategory.get(c.name) || 0;
    const minimum = Math.min(planned, Math.max(0,Number(c.minimumAmount)||0));
    const variance = actual - planned;
    let status = 'Within plan'; if (actual > planned && planned >= 0) status = 'Over plan'; else if (planned > 0 && actual >= planned * 0.85) status = 'Near limit';
    const recommendation = status === 'Over plan'
      ? `Review ${c.name} transactions and confirm whether the overrun is necessary before reducing it.`
      : status === 'Near limit' ? `Monitor ${c.name} for the rest of the budget period.`
      : c.essentiality === 'essential' ? `Protect the essential minimum for ${c.name}; consider changes only after checking operational needs.`
      : `Keep tracking ${c.name}; use actual outcomes before changing its allocation.`;
    return { category:c.name, plannedAmount:roundMoney(planned), actualSpend:roundMoney(actual), variance:roundMoney(variance), minimumAmount:roundMoney(minimum), essentiality:c.essentiality || 'flexible', status, recommendation, savingsEstimate:null };
  });
  const uncategorizedSpend = expenses.filter(e => !categories.some(c=>c.name===e.category)).reduce((s,e)=>s+Number(e.amount||0),0);
  const plannedRemaining = budget - reserve - allocated;
  return {
    totalBudget:roundMoney(budget), reserveAmount:roundMoney(reserve), spendableBudget:roundMoney(spendable),
    plannedCategoryTotal:roundMoney(allocated), unallocatedAmount:roundMoney(Math.max(0,plannedRemaining)), allocationOverrun:roundMoney(Math.max(0,-plannedRemaining)),
    totalActualSpend:roundMoney(expenses.reduce((s,e)=>s+Number(e.amount||0),0)), uncategorizedSpend:roundMoney(uncategorizedSpend),
    lines, methodology:'Rule-based variance analysis using user-entered plans and actual expenses. It does not infer ideal allocations or promise savings. Savings estimates are withheld until sufficient validated benchmarks or causal evidence exist.',
    dataWarnings:[...(categories.length===0?['Add budget categories before requesting category-level recommendations.']:[]),...(expenses.length===0?['No expense history found; recommendations are limited to budget structure, not spending patterns.']:[]),...(plannedRemaining<-.01?['Planned category allocations plus reserve exceed the total budget.']:[]),...(uncategorizedSpend>0?['Some expenses use categories that are not present in the budget.']:[])]
  };
}
