import mongoose from 'mongoose';
const expenseSchema = new mongoose.Schema({ user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true }, category: { type: String, required: true, trim: true, maxlength: 80 }, amount: { type: Number, required: true, min: 0.01 }, date: { type: Date, required: true }, vendor: { type: String, default: '', maxlength: 150 }, note: { type: String, default: '', maxlength: 500 }, essentiality: { type: String, enum: ['essential', 'flexible', 'discretionary'], default: 'flexible' } }, { timestamps: true });
expenseSchema.index({ user: 1, date: -1 });
export default mongoose.model('Expense', expenseSchema);
