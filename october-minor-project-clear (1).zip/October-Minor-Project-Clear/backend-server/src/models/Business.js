import mongoose from 'mongoose';
const businessSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  name: { type: String, default: '', trim: true, maxlength: 150 },
  type: { type: String, default: 'Small Business' }, industry: { type: String, default: '' }, country: { type: String, default: 'India' }, state: { type: String, default: '' }, city: { type: String, default: '' },
  employees: { type: Number, min: 0, default: 0 }, monthlyRevenue: { type: Number, min: 0, default: 0 }, monthlyBudget: { type: Number, min: 0, default: 0 }, availableCash: { type: Number, min: 0, default: 0 }, loanBalance: { type: Number, min: 0, default: 0 }, goals: [{ type: String }], currency: { type: String, default: 'INR' }
}, { timestamps: true });
export default mongoose.model('Business', businessSchema);
