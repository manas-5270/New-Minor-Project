import { Router } from 'express';
import { z } from 'zod';
import auth from '../middleware/auth.js';
import Business from '../models/Business.js';
const router = Router(); router.use(auth);
const schema = z.object({ name: z.string().trim().max(150).optional(), type: z.string().max(80).optional(), industry: z.string().max(100).optional(), country: z.string().max(80).optional(), state: z.string().max(80).optional(), city: z.string().max(80).optional(), employees: z.coerce.number().min(0).optional(), monthlyRevenue: z.coerce.number().min(0).optional(), monthlyBudget: z.coerce.number().min(0).optional(), availableCash: z.coerce.number().min(0).optional(), loanBalance: z.coerce.number().min(0).optional(), goals: z.array(z.string().max(80)).optional(), currency: z.string().length(3).optional() });
router.get('/', async (req,res,next)=>{ try { res.json({ business: await Business.findOne({user:req.userId}) }); } catch(e){next(e);} });
router.put('/', async (req,res,next)=>{ try { const p=schema.safeParse(req.body); if(!p.success) return res.status(400).json({message:p.error.issues[0].message}); const business=await Business.findOneAndUpdate({user:req.userId},{$set:p.data,$setOnInsert:{user:req.userId}},{new:true,upsert:true,runValidators:true}); res.json({business}); } catch(e){next(e);} });
export default router;
