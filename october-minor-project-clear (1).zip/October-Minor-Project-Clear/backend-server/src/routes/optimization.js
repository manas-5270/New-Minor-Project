import { Router } from 'express';
import auth from '../middleware/auth.js';
import Budget from '../models/Budget.js';
import Expense from '../models/Expense.js';
import { optimizeBudget } from '../services/optimizer.js';
const router=Router();router.use(auth);
router.post('/run',async(req,res,next)=>{try{const budget=await Budget.findOne({user:req.userId});if(!budget)return res.status(400).json({message:'Create a budget before running optimization.'});const from=new Date(`${budget.period}-01T00:00:00.000Z`);const [y,m]=budget.period.split('-').map(Number);const to=new Date(Date.UTC(y,m,1));const expenses=await Expense.find({user:req.userId,date:{$gte:from,$lt:to}}).lean();res.json({result:optimizeBudget({totalBudget:budget.totalBudget,reserveAmount:budget.reserveAmount,categories:budget.categories,expenses})});}catch(e){next(e);}});
export default router;
