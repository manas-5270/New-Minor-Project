import { Router } from 'express';
import { z } from 'zod';
import auth from '../middleware/auth.js';
import Budget from '../models/Budget.js';
const router=Router();router.use(auth);
const schema=z.object({period:z.string().regex(/^\d{4}-\d{2}$/).optional(),totalBudget:z.coerce.number().min(0),reserveAmount:z.coerce.number().min(0).default(0),categories:z.array(z.object({name:z.string().trim().min(2).max(80),plannedAmount:z.coerce.number().min(0),essentiality:z.enum(['essential','flexible','discretionary']).default('flexible'),minimumAmount:z.coerce.number().min(0).default(0),notes:z.string().max(300).optional()})).max(50)});
router.get('/',async(req,res,next)=>{try{res.json({budget:await Budget.findOne({user:req.userId})});}catch(e){next(e);}});
router.put('/',async(req,res,next)=>{try{const p=schema.safeParse(req.body);if(!p.success)return res.status(400).json({message:p.error.issues[0].message});const sum=p.data.categories.reduce((a,c)=>a+c.plannedAmount,0)+p.data.reserveAmount;if(sum>p.data.totalBudget+0.01)return res.status(400).json({message:'Category allocations plus reserve cannot exceed total budget.'});const budget=await Budget.findOneAndUpdate({user:req.userId},{$set:p.data,$setOnInsert:{user:req.userId}},{new:true,upsert:true,runValidators:true});res.json({budget});}catch(e){next(e);}});
export default router;
