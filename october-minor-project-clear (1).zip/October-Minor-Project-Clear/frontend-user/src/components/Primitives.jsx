import React from'react';
export const PageHeader=({eyebrow,title,subtitle,action})=><div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action&&<div>{action}</div>}</div>;
export const StatCard=({label,value,detail,icon:Icon,tone='blue'})=><div className={`stat-card tone-${tone}`}><div className="stat-top"><span>{label}</span><div className="stat-icon"><Icon size={18}/></div></div><strong>{value}</strong><small>{detail}</small></div>;
export const Notice=({children,type='info'})=><div className={`notice notice-${type}`}>{children}</div>;
